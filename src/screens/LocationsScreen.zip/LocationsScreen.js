import React, { useEffect, useState } from "react";
import { View, Text, Pressable, Alert } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEY = "pp_locations_v1";

const DEFAULT_LOCATIONS = [
  { id: "a", name: "Coffee Shop A", address: "123 Main St", city: "Los Angeles", state: "CA", restrooms: 1 },
  { id: "b", name: "Restaurant B", address: "88 Market Ave", city: "Pasadena", state: "CA", restrooms: 2 },
  { id: "c", name: "Library C", address: "10 Park Blvd", city: "Santa Monica", state: "CA", restrooms: 4 },
];

export default function LocationsScreen({ navigation }) {
  const [locations, setLocations] = useState(DEFAULT_LOCATIONS);

  useEffect(() => {
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw) {
          const saved = JSON.parse(raw);
          if (Array.isArray(saved)) setLocations(saved);
        } else {
          await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_LOCATIONS));
        }
      } catch (e) {
        // ignore
      }
    })();
  }, []);

  // When coming back from AdminAddLocation, refresh list
  useEffect(() => {
    const unsubscribe = navigation.addListener("focus", async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        const saved = raw ? JSON.parse(raw) : null;
        if (Array.isArray(saved)) setLocations(saved);
      } catch (e) {}
    });

    return unsubscribe;
  }, [navigation]);

  const clearAll = async () => {
    Alert.alert("Reset locations?", "This will restore the default locations.", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Reset",
        style: "destructive",
        onPress: async () => {
          await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_LOCATIONS));
          setLocations(DEFAULT_LOCATIONS);
        },
      },
    ]);
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#F9FAFB", padding: 24, paddingTop: 60 }}>
      <Text style={{ fontSize: 34, fontWeight: "900", color: "#111827" }}>
        Participating Locations
      </Text>

      <Text style={{ marginTop: 8, fontSize: 14, color: "#6B7280" }}>
        Tap a location for details.
      </Text>

      <View style={{ flexDirection: "row", gap: 10, marginTop: 14 }}>
        <Pressable
          onPress={() => navigation.navigate("AdminAddLocation")}
          style={{
            flex: 1,
            backgroundColor: "#2563EB",
            borderRadius: 16,
            paddingVertical: 14,
            alignItems: "center",
          }}
        >
          <Text style={{ color: "white", fontWeight: "900" }}>+ Add</Text>
        </Pressable>

        <Pressable
          onPress={clearAll}
          style={{
            flex: 1,
            backgroundColor: "#111827",
            borderRadius: 16,
            paddingVertical: 14,
            alignItems: "center",
          }}
        >
          <Text style={{ color: "white", fontWeight: "900" }}>Reset</Text>
        </Pressable>
      </View>

      <View style={{ marginTop: 18, gap: 14 }}>
        {locations.map((loc) => (
          <Pressable
            key={loc.id}
            onPress={() =>
              navigation.navigate("LocationDetail", {
                name: loc.name,
                address: loc.address,
                city: loc.city,
                state: loc.state,
                restrooms: loc.restrooms,
              })
            }
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 18,
              padding: 18,
              borderWidth: 1,
              borderColor: "#E5E7EB",
            }}
          >
            <Text style={{ fontSize: 20, fontWeight: "900", color: "#111827" }}>
              {loc.name}
            </Text>

            <Text style={{ marginTop: 6, fontSize: 15, color: "#6B7280" }}>
              {loc.address}
            </Text>

            <Text style={{ marginTop: 4, fontSize: 14, color: "#6B7280" }}>
              {loc.city}, {loc.state} · 🚻 {loc.restrooms}
            </Text>
          </Pressable>
        ))}
      </View>

      <Pressable
        onPress={() => navigation.navigate("Card")}
        style={{
          marginTop: 22,
          backgroundColor: "#111827",
          borderRadius: 18,
          paddingVertical: 16,
          alignItems: "center",
        }}
      >
        <Text style={{ color: "white", fontWeight: "800", fontSize: 16 }}>
          Back to Card
        </Text>
      </Pressable>
    </View>
  );
}
